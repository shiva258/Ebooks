package com.praveen.hms.service;

public class DiseaseService {

}
