@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.soap.apachecxf.praveen.com/")
package com.praveen.apachecxf.soap.service;
