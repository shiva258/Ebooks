package com.nt.beans;

public class WishMessageGenerator {
public WishMessageGenerator() {
	System.out.println("welcome");
	System.out.println("WishMessageGenerator zero param COnstructor>>>>>>>");
}
}
