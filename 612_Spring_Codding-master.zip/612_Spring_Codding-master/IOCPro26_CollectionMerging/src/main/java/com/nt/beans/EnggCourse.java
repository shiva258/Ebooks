package com.nt.beans;

import java.util.Set;

import lombok.Setter;
import lombok.ToString;
@Setter
@ToString
public class EnggCourse {
private Set<String> subjects;

}
