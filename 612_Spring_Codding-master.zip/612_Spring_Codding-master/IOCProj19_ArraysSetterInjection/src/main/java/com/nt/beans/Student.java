package com.nt.beans;

import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class Student {

	private int marks[];
}
