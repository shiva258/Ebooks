package com.nt.beans;

public class Address {
//fields 
	int eid;
	String ename;
	String ecity;
}
