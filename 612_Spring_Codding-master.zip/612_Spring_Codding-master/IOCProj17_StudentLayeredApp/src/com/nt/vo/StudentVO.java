package com.nt.vo;

//VO class carry inputs and outputs 
//java bean class
public class StudentVO {
	// bean properties
	private String stdNo;
	private String stdName;
	private String stdAddr;
	private String stdM1;
	private String stdM2;
	private String stdM3;

	// setters and getters
	public String getStdNo() {
		return stdNo;
	}

	public void setStdNo(String stdNo) {
		this.stdNo = stdNo;
	}

	public String getStdName() {
		return stdName;
	}

	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	public String getStdAddr() {
		return stdAddr;
	}

	public void setStdAddr(String stdAddr) {
		this.stdAddr = stdAddr;
	}

	public String getStdM1() {
		return stdM1;
	}

	public void setStdM1(String stdM1) {
		this.stdM1 = stdM1;
	}

	public String getStdM2() {
		return stdM2;
	}

	public void setStdM2(String stdM2) {
		this.stdM2 = stdM2;
	}

	public String getStdM3() {
		return stdM3;
	}

	public void setStdM3(String stdM3) {
		this.stdM3 = stdM3;
	}

}
